#include "proc.h"
#include "memory.h"

static void *pf = NULL;

void *new_page(void)
{
	assert(pf < (void *)_heap.end);
	void *p = pf;
	pf += PGSIZE;
	return p;
}

void free_page(void *p)
{
	panic("not implement yet");
}

/* The brk() system call handler. */
//brk:堆的末尾指针
//把新申请的堆区映射到虚拟地址空间中
int mm_brk(uint32_t new_brk)
{
	// return 0;
	if (current->cur_brk == 0)
	{												   // 如果当前 brk 尚未初始化，也就是第一次调用
		current->cur_brk = current->max_brk = new_brk; // 初始化 cur_brk 和 max_brk，均指向 new_brk
	}
	else
	{ // 当 new_brk 超过当前 max_brk 时，分配新的内存页
		if (new_brk > current->max_brk)
		{
			uint32_t first = PGROUNDUP(current->max_brk); // 计算从 max_brk 开始的第一个页对齐地址
			uint32_t end = PGROUNDDOWN(new_brk);		  // 计算 new_brk 对齐后的结束地址

			if ((new_brk & 0xfff) == 0)
			{ // 如果 new_brk 刚好为页边界，需要向下调整 end
				end -= PGSIZE;
			}
			Log("first=0x%x,end=0x%x", first, end);

			// 遍历页边界范围，从 first 到 end，逐页分配
			for (uint32_t va = first; va <= end; va += PGSIZE)
			{
				void *pa = new_page();
				_map(&(current->as), (void *)va, pa); // 将分配的物理页映射到虚拟地址空间
			}
			current->max_brk = new_brk; // 更新 max_brk
		}
		current->cur_brk = new_brk; // 更新 cur_brk
	}
	return 0;
}

void init_mm()
{
	pf = (void *)PGROUNDUP((uintptr_t)_heap.start);//空闲物理页向上对齐
	Log("free physical pages starting from %p", pf);

	_pte_init(new_page, free_page);
}

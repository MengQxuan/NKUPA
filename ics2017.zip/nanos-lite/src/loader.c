#include "common.h"
#include "fs.h"
#include "memory.h"

#define DEFAULT_ENTRY ((void *)0x8048000)

extern uint8_t ramdisk_start;
extern uint8_t ramdisk_end;
#define RAMDISK_SIZE ((&ramdisk_end) - (&ramdisk_start))

// 从ramdisk中offset偏移处的len字节读入到buf中
void ramdisk_read(void *buf, off_t offset, size_t len);
// 把buf中的len字节写入到ramdisk中offset 偏移处
void ramdisk_write(const void *buf, off_t offset, size_t len);
// 返回ramdisk的大小，单位为字节
size_t get_ramdisk_size();

uintptr_t loader(_Protect *as, const char *filename)
{
	// TODO();
	// size_t len = get_ramdisk_size();
	// ramdisk_read(DEFAULT_ENTRY, 0, len);
	// return (uintptr_t)DEFAULT_ENTRY;

	// Log("The image is %s", filename);
	// int fd = fs_open(filename, 0, 0);
	// Log("filename=%s,fd=%d", filename, fd);
	// fs_read(fd, (void *)DEFAULT_ENTRY, fs_filesz(fd));
	// fs_close(fd);
	// return (uintptr_t)DEFAULT_ENTRY;

	int fd = fs_open(filename, 0, 0);
	Log("filename = %s,fd = %d", filename, fd);
	int size = fs_filesz(fd);
	// 计算需要的页数，每页大小为 PGSIZE
	int ppnum = size / PGSIZE;
	if (size % PGSIZE != 0)
		ppnum++;

	void *pa = NULL;		  // 物理地址指针
	void *va = DEFAULT_ENTRY; // 虚拟地址起始地址
	// 遍历每一页，分配内存并映射
	for (int i = 0; i < ppnum; i++)
	{
		pa = new_page();		 // 分配新的物理页
		_map(as, va, pa);		 // 建立虚拟地址到物理地址的映射
		fs_read(fd, pa, PGSIZE); // 从文件读取一页数据到物理内存
		va += PGSIZE;			 // 更新虚拟地址，指向下一页
	}
	fs_close(fd);
	return (uintptr_t)DEFAULT_ENTRY;
}
